class Drink:
    # Defines valid bases and vald flavors for drinks
    _valid_bases = {"water", "sbrite", "pokacola", "Mr.Salt", "hill fog", "leaf wine"}
    _valid_flavors = {"lemon", "cherry", "strawberry", "mint", "blueberry", "lime"}

    def __init__(self):
        # Makes the drink with no base and an empty flavor set
        self._base = None
        self._flavors = set()

    def get_base(self):
        # Returns the base of the drink
        return self._base
    
    def get_flavors(self):
        # Returns a list of the flavors
        return list(self._flavors)
    
    def get_num_flavors(self):
        # Returns the amount of flavors
        return len(self._flavors)
    
    def set_base(self, base):
        # Returns the base of the drink as long as its a valid choice
        if base in self._valid_bases:
            self._base = base
        else:
            raise ValueError(f"Pick a proper base from{self._valid_bases}.")
    
    def add_flavor(self, flavor):
        # Adds a flavor in the drink as long as it is valid
        if self in self._valid_flavors:
            self._flavors.add(flavor)
        else:
            raise ValueError(f"Pick a proper flavor from{self._valid_flavors}.")
        
    def set_flavors(self, flavors):
        # Adds multiple flavors to the drink as long as they are valid choices
        for flavor in flavors:
            if flavor not in self._valid_flavors:
                raise ValueError(f"Pick a proper flavor from{self._valid_flavors}.")
        self._flavors = set(flavors)

class Order:
    def __init__(self):
        # Creates an empty list to store drink items in the order
        self._items = []
    
    def get_items(self):
        # Returns a list of all the items in the order
        return self._items
    
    def get_total(self):
        # Returns the total number of drinks in the order
        return len(self._items)
    
    def get_receipt(self):
        # Creates and returns a receipt for the order as a string
        receipt = "Your order receipt:\n"
        for i, drink in enumerate(self._items):
            # This part gets the base and flavors of each drink
            base = drink.get_base()
            flavors = ", ".join(drink.get_flavors())
            # This part makes the list of flavors easier to read on the receipt
            receipt += f"{i +1}: base - {base}, flavors - {flavors}\n"
            return receipt
        
    def add_item(self, drink):
        # Adds a drink to the order if everything is valid
        if isinstance(drink, Drink):
            self. _items.append(drink)
        else:
            raise ValueError("You can only add drinks to this order.")
        
    def remove_item(self, index):
        # Removes a drink from the order when the person doesn't have enough money
        if 0 <= index < len(self._items):
            self._items.pop(index)
        else:
            raise IndexError("Invalid, cannot remove")
    
