class Drink:
    # Defines valid bases and vald flavors for drinks
    _valid_bases = {"water", "sbrite", "pokacola", "Mr.Salt", "hill fog", "leaf wine"}
    _valid_flavors = {"lemon", "cherry", "strawberry", "mint", "blueberry", "lime"}
    _size_costs = {
        "small": 1.50,
        "medium": 1.75,
        "large": 2.05,
        "mega": 2.15
    }

    def __init__(self, size):
        # Makes the drink with no base and an empty flavor set as well as getting the size information
        self._base = None
        self._flavors = set()
        self._size = None
        self._cost = 0.0
        self.set_size(size)

    def get_base(self):
        # Returns the base of the drink
        return self._base
    
    def get_flavors(self):
        # Returns a list of the flavors
        return list(self._flavors)
    
    def get_num_flavors(self):
        # Returns the amount of flavors
        return len(self._flavors)
    
    def get_total(self):
        return self._cost
    
    def set_base(self, base):
        # Returns the base of the drink as long as its a valid choice
        if base in self._valid_bases:
            self._base = base
        else:
            raise ValueError(f"Pick a proper base from{self._valid_bases}.")
    
    def add_flavor(self, flavor):
        # Adds a flavor in the drink as long as it is valid
        if self in self._valid_flavors:
            if flavor not in self._flavors:
                self._cost += 0.15
            self._flavors.add(flavor)
        else:
            raise ValueError(f"Pick a proper flavor from{self._valid_flavors}.")
        
    def set_flavors(self, flavors):
        # Adds multiple flavors to the drink as long as they are valid choices
        for flavor in flavors:
            new_flavors = set(flavors)-self._flavors
            self._cost += .15 * len(new_flavors)
            if flavor not in self._valid_flavors:
                raise ValueError(f"Pick a proper flavor from{self._valid_flavors}.")
        self._flavors = set(flavors)
    
    def set_size(self, size):
        size = size.lower()
        if size in self._size_costs:
            size._size = size
            self._cost = size._size_costs[size] + .15 * len(self._flavors)
        else:
            raise ValueError(f"Invalid size: {size}. Choose a different size from {list(self._size_costs.keys())}.")


class Order:

    _tax_rate = 0.0725

    def __init__(self):
        # Creates an empty list to store drink items in the order
        self._items = []
    
    def get_items(self):
        # Returns a list of all the items in the order
        return self._items
        
    def get_total(self):
        # Returns the total number of drinks in the order
        return sum(drink.get_total() for drink in self._items)

    def get_receipt(self):
        # Creates and returns a receipt for the order as a string
        receipt_data = {
            "number_drinks": len(self._items),
            "drinks": [],
            "subtotal": self.get_total(),
            "tax": self.get_total() * self._tax_rate,
            "grand_total": self.get_tax()
        }
    
        for i, drink in enumerate(self._items):

            drink_data = {
                "number_drinks": i + 1,
                "base": drink.get_base(),
                "size": drink.get_size(),
                "flavors": drink.get_flavors(),
                "total_cost": drink.get_total()
            }
            receipt_data["drinks"].append(drink_data)
            # This part gets the base and flavors of each drink
            # base = drink.get_base()
            # flavors = ", ".join(drink.get_flavors())
            # This part makes the list of flavors easier to read on the receipt
            # receipt += f"{i +1}: base - {base}, flavors - {flavors}\n"
        return receipt_data
        
    def add_item(self, drink):
        # Adds a drink to the order if everything is valid
        if isinstance(drink, Drink):
            self. _items.append(drink)
        else:
            raise ValueError("You can only add drinks to this order.")
        
    def remove_item(self, index):
        # Removes a drink from the order when the person doesn't have enough money
        if 0 <= index < len(self._items):
            self._items.pop(index)
        else:
            raise IndexError("Invalid, cannot remove")
        
    def get_tax(self):
        return self.get_total * (1 + self._tax_rate)
        
